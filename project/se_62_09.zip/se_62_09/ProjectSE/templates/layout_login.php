<?php
    include Router::getSourcePath()."templates/layout_head.php"; 
?>

<body>
    <div id="container">
        <div id="content" style="text-align: center">
            <?= $content ?>
        </div>
    </div>
</body>

</html>