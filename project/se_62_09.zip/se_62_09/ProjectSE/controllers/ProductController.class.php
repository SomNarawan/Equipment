<?php
/**
 * Created by PhpStorm.
 * User: Diiar
 * Date: 24/1/2562
 * Time: 14:51
 */

class ProductController
{

    // ควรมีสำหรับ controller ทุกตัว
    private function index() {

    }
}