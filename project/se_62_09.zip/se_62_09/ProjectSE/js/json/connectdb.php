<?php

$db_name = "se62_09"; 
$mysql_username = "se62_09";
$mysql_password = "se62_09";
$server_name = "localhost";
$conn = mysqli_connect($server_name,$mysql_username,$mysql_password,$db_name );
mysqli_set_charset($conn,"utf8");

?>