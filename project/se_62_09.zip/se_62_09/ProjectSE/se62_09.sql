-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2020 at 06:10 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_09`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrowing`
--

CREATE TABLE `borrowing` (
  `id_b` int(11) NOT NULL,
  `id_i` varchar(20) DEFAULT NULL,
  `dateTime_b` datetime DEFAULT NULL,
  `dateTime_r` datetime DEFAULT NULL,
  `note` text,
  `id_dc` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `borrowing`
--

INSERT INTO `borrowing` (`id_b`, `id_i`, `dateTime_b`, `dateTime_r`, `note`, `id_dc`) VALUES
(1, 'TA001', '2020-03-06 00:00:00', '2020-03-09 00:00:00', NULL, 4),
(2, 'TA003', '2026-03-20 02:50:25', '2026-03-20 02:53:36', NULL, 4),
(3, 'CM001', '2020-03-06 00:00:00', '0000-00-00 00:00:00', NULL, 5),
(4, NULL, NULL, NULL, NULL, 6),
(5, 'TA003', '2020-03-17 00:00:00', NULL, NULL, 9),
(6, 'TA004', '2020-03-17 00:00:00', NULL, NULL, 9),
(7, 'CM002', NULL, NULL, NULL, 10),
(8, 'CI001', '2020-03-26 00:00:00', '2020-03-27 00:00:00', NULL, 11),
(9, 'CI002', '2020-03-26 00:00:00', '2020-03-27 00:00:00', NULL, 11),
(10, 'CI002', '2020-02-28 00:00:00', '2020-04-15 00:00:00', NULL, 12),
(11, 'CI003', '2020-03-18 00:00:00', NULL, NULL, 12),
(12, 'CI004', NULL, NULL, NULL, 12),
(13, 'CM003', '2020-03-02 00:00:00', '2020-03-05 00:00:00', NULL, 13),
(14, 'CM004', '2020-03-03 00:00:00', NULL, NULL, 13),
(15, 'CN001', '2020-03-18 00:00:00', NULL, NULL, 14),
(16, 'CI002', '2020-03-29 00:00:00', NULL, NULL, 17),
(17, 'CI004', '2020-03-28 00:00:00', '2020-03-30 00:00:00', NULL, 17),
(18, 'CI005', NULL, NULL, NULL, 17),
(19, 'CN006', '2020-03-30 00:00:00', NULL, 'จะนำมาคืนภายใน 3 เดือน', 17),
(20, 'CM003', NULL, NULL, NULL, 18);

-- --------------------------------------------------------

--
-- Table structure for table `confirm`
--

CREATE TABLE `confirm` (
  `id_c` int(11) NOT NULL,
  `dateTime_c` datetime NOT NULL,
  `id_resp` int(11) DEFAULT NULL,
  `id_u` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `confirm`
--

INSERT INTO `confirm` (`id_c`, `dateTime_c`, `id_resp`, `id_u`, `reason`) VALUES
(1, '2020-03-01 00:00:00', 3, 1, 'ทำโครงงาน'),
(2, '2020-03-03 00:00:00', 3, 2, 'ทำโครงงาน'),
(5, '2020-03-11 00:00:00', NULL, 3, 'สอนนิสิต'),
(6, '2020-03-16 00:00:00', NULL, 5, 'ทำงาน'),
(7, '2020-03-09 00:00:00', NULL, 6, 'ใช้ทำงานสัมมนาภาควิชา'),
(8, '2020-03-11 00:00:00', NULL, 6, 'ใช้ทำงานสัมมนามหาลัย'),
(9, '2020-03-13 00:00:00', NULL, 6, 'ทำงานบัญชีการเงินภาค'),
(10, '2020-02-11 00:00:00', NULL, 9, 'สอนวิชาแลป'),
(11, '2020-02-09 00:00:00', NULL, 9, 'สอนวิชาบรรยาย'),
(12, '2020-02-24 00:00:00', NULL, 9, 'ใช้ในการประชุม'),
(13, '2020-03-09 00:00:00', 9, 10, 'ทำโปรเจ็ก se'),
(14, '2020-03-10 00:00:00', 9, 10, 'ทำโปรเจ็ก mit'),
(15, '2020-03-11 00:00:00', 9, 10, 'ทำโปรเจ็ก ระบบฝังตัว'),
(16, '2020-03-17 00:00:00', 9, 7, 'ใช้ในการสอบย่อย'),
(17, '2020-03-18 00:00:00', 9, 7, 'ใช้ในการสอบกลางภาค'),
(18, '2020-03-19 00:00:00', 9, 8, 'ใช้ทำโปรเจ็กส์จบ'),
(19, '2020-03-20 00:00:00', 9, 8, 'ใช้ดูหนัง');

-- --------------------------------------------------------

--
-- Table structure for table `detailconfirm`
--

CREATE TABLE `detailconfirm` (
  `id_dc` int(11) NOT NULL,
  `id_e` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `deny` text,
  `dateTime_dc` datetime DEFAULT NULL,
  `id_c` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `detailconfirm`
--

INSERT INTO `detailconfirm` (`id_dc`, `id_e`, `num`, `status`, `deny`, `dateTime_dc`, `id_c`) VALUES
(4, 1, 2, 1, NULL, '2020-03-04 00:00:00', 1),
(5, 4, 1, 1, NULL, '2020-03-04 00:00:00', 1),
(6, 5, 1, 1, NULL, '2020-03-02 00:00:00', 2),
(7, 5, 1, 1, NULL, NULL, 5),
(8, 5, 2, 1, NULL, NULL, 6),
(9, 1, 2, 1, NULL, NULL, 7),
(10, 2, 1, 1, NULL, NULL, 8),
(11, 3, 2, 1, NULL, NULL, 9),
(12, 3, 3, 1, NULL, NULL, 10),
(13, 4, 2, 1, NULL, NULL, 11),
(14, 5, 1, 1, NULL, NULL, 12),
(15, 5, 2, NULL, NULL, NULL, 13),
(16, 5, 2, 0, 'ไม่อนุญาติให้ใช้โน๊ตบุ้คภาคทำงานส่วนตัว', '2020-03-26 00:00:00', 14),
(17, 3, 3, 1, NULL, '2020-03-25 00:00:00', 15),
(18, 5, 1, 1, NULL, '2020-03-24 00:00:00', 16),
(19, 4, 1, 1, NULL, '2020-03-25 00:00:00', 17),
(20, 5, 1, NULL, NULL, NULL, 18),
(21, 5, 1, NULL, 'ไม่ให้นิสิตนำไปเพื่อความบันเทิง', '2020-03-26 00:00:00', 19);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `id_e` int(11) NOT NULL,
  `name_e` varchar(50) NOT NULL,
  `id_t` int(11) NOT NULL,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id_e`, `name_e`, `id_t`, `note`) VALUES
(1, 'android', 2, 'OPPO A38'),
(2, 'IOS', 2, 'Iphone 6'),
(3, 'จอ', 1, 'DELL'),
(4, 'เมาส์', 1, 'LOGITEC'),
(5, 'โน๊ตบุ๊ค', 1, 'ACER');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id_i` varchar(20) NOT NULL,
  `note` text,
  `id_e` int(11) NOT NULL,
  `status_i` enum('1','2','3') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id_i`, `note`, `id_e`, `status_i`) VALUES
('CI001', NULL, 3, '1'),
('CI002', NULL, 3, '2'),
('CI003', NULL, 3, '2'),
('CI004', NULL, 3, '1'),
('CI005', NULL, 3, '1'),
('CM001', 'สีดำ', 4, '2'),
('CM002', 'สีดำ', 4, '1'),
('CM003', 'สีดำ', 4, '1'),
('CM004', 'สีดำ', 4, '2'),
('CN001', NULL, 5, '2'),
('CN002', NULL, 5, '1'),
('CN003', NULL, 5, '1'),
('CN004', NULL, 5, '1'),
('CN005', NULL, 5, '1'),
('CN006', NULL, 5, '2'),
('CN007', 'MAC', 5, '3'),
('TA001', 'สีขาว', 1, '2'),
('TA002', 'สีขาว', 1, '2'),
('TA003', 'สีขาว', 1, '2'),
('TA004', 'สีดำ', 1, '2'),
('TA005', 'สีเขียว', 1, '1'),
('TA006', '', 1, '3'),
('TA009', 'สีดำ', 1, '1'),
('TI001', 'สี silver', 2, '1'),
('TI002', 'สี rose gold', 2, '1');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `username` varchar(55) NOT NULL,
  `passwd` varchar(55) NOT NULL,
  `name` varchar(55) NOT NULL,
  `surname` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `username`, `passwd`, `name`, `surname`) VALUES
(1, 'admin', 'adminpass', 'nutcha', 'sattaya'),
(2, 'admin2', 'password', 'somsak', 'sornpeng');

-- --------------------------------------------------------

--
-- Table structure for table `type`
--

CREATE TABLE `type` (
  `id_t` int(11) NOT NULL,
  `name_t` varchar(50) NOT NULL,
  `note` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type`
--

INSERT INTO `type` (`id_t`, `name_t`, `note`) VALUES
(1, 'คอมพิวเตอร์', NULL),
(2, 'โทรศัพท์', NULL),
(6, 'อุปกรณ์คอมพิวเตอร์', ''),
(7, 'กุญแจ', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_u` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `title` enum('นาย','นาง','นางสาว') NOT NULL,
  `name` varchar(50) NOT NULL,
  `surname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `role` enum('o','s','t') NOT NULL,
  `passwd` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_u`, `username`, `title`, `name`, `surname`, `email`, `phone`, `role`, `passwd`) VALUES
(1, 'b6020503801', 'นางสาว', 'ธัญชนก', 'ศรีทองคำ', 'thanchanok@ku.th', '0985241256', 's', '123456'),
(2, 'b6020503810', 'นางสาว', 'ธีรยา', 'เลปนะสุวรรณ', 'Teeraya@ku.th', '0874512621', 's', '123456'),
(3, 'fengt', 'นางสาว', 'อาจารย์', 'ใจดี', 'teacher1@ku.th', '0845124563', 't', '123456'),
(4, 'fengtea', 'นาย', 'ครู', 'สมใจ', 'teacer2@ku.th', '0956125487', 't', '123456'),
(5, 'opt', 'นางสาว', 'พนักงาน', 'จัดการ', 'operator@ku.th', '0984152632', 'o', '123456'),
(6, 'admin', 'นางสาว', 'แอดมิน', 'แอดมิน', 'admin@gmail.com', '0854123654', 'o', 'admin'),
(7, 'b6020501361', 'นางสาว', 'นราวัลย์', 'เอี่ยมสอาด', 'nalawan.i@ku.th', '0983548125', 's', '123456'),
(8, 'b6020501345', 'นาย', 'นราธร', 'ไชยสลี', 'naratorn.c@ku.th', '0880801001', 's', '123456'),
(9, 'tacher', 'นาง', 'อาจารย์', 'ตั้งใจสอน', 'tacher@ku.th', '0874585414', 't', 'tacher'),
(10, 'student', 'นาย', 'นักเรียน', 'ตั้งใจเรียน', 'student@ku.th', '0874445126', 's', 'student');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD PRIMARY KEY (`id_b`),
  ADD KEY `id_i` (`id_i`),
  ADD KEY `id_dc` (`id_dc`);

--
-- Indexes for table `confirm`
--
ALTER TABLE `confirm`
  ADD PRIMARY KEY (`id_c`),
  ADD KEY `id_resp` (`id_resp`),
  ADD KEY `id_u` (`id_u`);

--
-- Indexes for table `detailconfirm`
--
ALTER TABLE `detailconfirm`
  ADD PRIMARY KEY (`id_dc`),
  ADD KEY `id_e` (`id_e`),
  ADD KEY `id_c` (`id_c`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`id_e`),
  ADD KEY `id_t` (`id_t`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id_i`),
  ADD KEY `id_e` (`id_e`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `type`
--
ALTER TABLE `type`
  ADD PRIMARY KEY (`id_t`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_u`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `borrowing`
--
ALTER TABLE `borrowing`
  MODIFY `id_b` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `confirm`
--
ALTER TABLE `confirm`
  MODIFY `id_c` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=162;

--
-- AUTO_INCREMENT for table `detailconfirm`
--
ALTER TABLE `detailconfirm`
  MODIFY `id_dc` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `id_e` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type`
--
ALTER TABLE `type`
  MODIFY `id_t` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_u` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `borrowing`
--
ALTER TABLE `borrowing`
  ADD CONSTRAINT `borrowing_ibfk_2` FOREIGN KEY (`id_dc`) REFERENCES `detailconfirm` (`id_dc`),
  ADD CONSTRAINT `borrowing_ibfk_3` FOREIGN KEY (`id_i`) REFERENCES `item` (`id_i`);

--
-- Constraints for table `confirm`
--
ALTER TABLE `confirm`
  ADD CONSTRAINT `confirm_ibfk_2` FOREIGN KEY (`id_resp`) REFERENCES `users` (`id_u`),
  ADD CONSTRAINT `confirm_ibfk_3` FOREIGN KEY (`id_u`) REFERENCES `users` (`id_u`);

--
-- Constraints for table `detailconfirm`
--
ALTER TABLE `detailconfirm`
  ADD CONSTRAINT `detailconfirm_ibfk_1` FOREIGN KEY (`id_e`) REFERENCES `equipment` (`id_e`),
  ADD CONSTRAINT `detailconfirm_ibfk_2` FOREIGN KEY (`id_c`) REFERENCES `confirm` (`id_c`);

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`id_t`) REFERENCES `type` (`id_t`);

--
-- Constraints for table `item`
--
ALTER TABLE `item`
  ADD CONSTRAINT `item_ibfk_1` FOREIGN KEY (`id_e`) REFERENCES `equipment` (`id_e`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
